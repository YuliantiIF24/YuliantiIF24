# Analisis Manfaat In-Memory Database untuk Pemrosesan Data Skala Besar

**Mata Kuliah:** Sistem Basis Data Modern — S1 Informatika, Fakultas Teknik, Universitas Muhammadiyah Makassar
**Kelompok 4-E:** Windi, Yulianti, Sri Wahyuni Rahman, Muh. Rafli
**Dosen:** Muhyiddin A M Hayat, S.Kom., M.T

Repository ini berisi laporan kajian literatur beserta benchmark empiris pendukung yang membandingkan kinerja **In-Memory Database (Redis)** dengan **basis data berbasis disk (SQLite)**, sesuai materi Pertemuan 15 — Evaluasi Kinerja Sistem Basis Data (Sub-CPMK-3.4).

## 📄 Deskripsi Project

Project ini mengevaluasi kinerja sistem basis data dalam konteks solusi industri, dengan fokus pada In-Memory Database. Terdiri dari dua bagian:

1. **Kajian Literatur** (`/laporan`) — merangkum 6 penelitian empiris nasional (2020–2025) yang menganalisis penerapan Redis sebagai *caching layer* pada berbagai sistem produksi (e-learning, microservices, aplikasi pemerintahan, web service), mengukur dampaknya terhadap latency, throughput, dan beban basis data utama.
2. **Benchmark Empiris** (`/benchmark.py`) — pengujian langsung untuk memverifikasi klaim di laporan menggunakan metrik evaluasi kinerja standar (latency & throughput), membandingkan Redis (in-memory) dengan SQLite (disk-based) pada dua skenario beban kerja berbeda.

## 🔍 Temuan Utama dari Kajian Literatur

| Studi | Temuan |
|---|---|
| Zulfa et al. (2020) | Redis efektif mengatasi bottleneck I/O pada query JOIN kompleks di RDBMS |
| Dipraja & Rahman (2025) | Redis Cluster pada microservices: latency ↓40,6%, throughput ↑30,6%, beban DB ↓58% |
| Hartanto et al. (2023) | Cache Redis pada web service Lumen menurunkan beban database & meningkatkan efisiensi resource |
| Harianto (2023) | Redis menstabilkan performa platform e-learning Moodle saat lonjakan akses bersamaan |
| Nur Ramadhan & Saraswati (2023) | Redis mempercepat endpoint API yang sebelumnya lambat akibat query MySQL berat |

## 🧪 Benchmark: Metodologi & Hasil

Benchmark dirancang untuk menjawab pertanyaan kritis: **apakah keunggulan in-memory database selalu berlaku, atau bergantung pada karakteristik beban kerja?**

Dua skenario diuji dengan 20.000 baris data produk (relasi `products` × `categories` × `suppliers`), masing-masing dijalankan 5 kali (3.000 query/run):

### Skenario 1 — Point Lookup (JOIN sederhana, indexed)
SQLite mengeksekusi ulang JOIN 3 tabel per-request (cache-miss) vs Redis menyajikan hasil JOIN yang sudah di-cache (cache-hit).

| Metrik | SQLite (Disk) | Redis (In-Memory) |
|---|---|---|
| Latency rata-rata | 0,0064 ms | 0,0372 ms |
| Throughput | 155.893 ops/s | 26.954 ops/s |

**Hasil: Redis justru lebih lambat (−481%).** Untuk query indexed sederhana pada baris tunggal, overhead komunikasi antar-proses ke Redis (bahkan lewat unix socket) lebih mahal daripada biaya SQLite membaca satu baris terindeks yang sudah ada di OS page cache.

### Skenario 2 — Query Analitik Berat (agregasi + `GROUP BY`, full table scan)
Simulasi query dashboard (`COUNT`, `AVG`, `GROUP BY category` dengan filter harga) yang mahal secara komputasi jika dijalankan ulang tiap request.

| Metrik | SQLite (Disk) | Redis (In-Memory) |
|---|---|---|
| Latency rata-rata | 3,1207 ms | 0,0391 ms |
| Throughput | 321 ops/s | 25.764 ops/s |

**Hasil: Redis jauh lebih unggul — latency turun 98,75%, throughput naik ±80×.** Temuan ini konsisten dengan klaim literatur (Dipraja & Rahman, 2025; Zulfa et al., 2020).

### 🎯 Analisis Kritis (Sub-CPMK-3.4)

Manfaat In-Memory Database **tidak bersifat mutlak/universal**, melainkan bergantung pada karakteristik beban kerja:

- **Untuk query ringan & sudah terindeks** dengan baik pada basis data disk-based modern (yang sebagian datanya sudah berada di OS page cache), caching eksternal justru bisa menambah *overhead* komunikasi tanpa manfaat berarti.
- **Untuk query berat** (agregasi, JOIN kompleks, full scan, laporan analitik yang sering diulang dengan parameter sama), caching in-memory memberikan peningkatan performa yang sangat signifikan — karena biaya komputasi yang mahal hanya dibayar sekali (saat *cache warming*), lalu request berikutnya menjadi O(1) lookup.
- Implikasi praktis: strategi **hybrid** (Prasetyo et al., 2024; Hartanto et al., 2023) — Redis sebagai *cache layer* selektif untuk *query* mahal, bukan pengganti seluruh basis data utama — adalah pendekatan yang tepat, bukan aturan umum yang berlaku pada semua jenis operasi.

Ini menjawab langsung tujuan asesmen (Sub-CPMK-3.4): mengevaluasi kinerja secara kritis, bukan sekadar mengonfirmasi literatur, tetapi menguji batas berlakunya klaim tersebut secara empiris.

## 🗂 Struktur Repository

```
├── laporan/
│   └── LAPORAN_BASIS_DATA__Kelompok_4-E.pdf   # Laporan lengkap (BAB I-III + daftar pustaka)
├── benchmark.py                                # Script benchmark Redis vs SQLite
├── results/
│   └── benchmark_results.json                  # Hasil mentah benchmark (2 skenario, 5 run)
├── requirements.txt
└── README.md
```

## ▶️ Menjalankan Benchmark

```bash
# 1. Jalankan Redis server (unix socket)
redis-server --daemonize yes --port 0 --unixsocket /tmp/redis_benchmark.sock --unixsocketperm 700

# 2. Install dependensi
pip install -r requirements.txt

# 3. Jalankan benchmark
python3 benchmark.py
```

Hasil akan dicetak ke terminal dan disimpan di `results/benchmark_results.json`.

## 📚 Referensi

Lihat daftar pustaka lengkap pada laporan PDF di folder `/laporan`. Enam sumber utama:

- Zulfa, M. I., Fadli, A., & Wardhana, A. W. (2020). *Jurnal Teknologi dan Sistem Komputer*, 8(2), 157–163.
- Prasetyo, D. R., Fatoni, Nasir, M., & Effendy, I. (2024). *Explore: Jurnal Sistem Informasi dan Telematika*, 15(2), 214–223.
- Hartanto, M. B., Fawa, T. M., & Hendro, D. E. P. (2023). *Jurnal Alih Teknologi Komputer (ALTEK)*, 4(2).
- Dipraja, F., & Rahman, A. (2025). *Intellect: Indonesian Journal of Learning and Technological Innovation*, 4(1), 171–179.
- Harianto, A. H. T. (2023). *J-PTIIK*, 7(6), 2889–2894.
- Nur Ramadhan, I., & Saraswati, G. W. (2024). *Technomedia Journal*, 8(3), 394–406.
