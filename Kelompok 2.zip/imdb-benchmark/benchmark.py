"""
Benchmark: In-Memory Database (Redis) vs Disk-Based Database (SQLite)
======================================================================
Studi Kasus Pendukung Laporan:
"Analisis Manfaat In-Memory Database untuk Pemrosesan Data Skala Besar"
Kelompok 4-E - Sistem Basis Data Modern - Unismuh Makassar

Tujuan:
Membuktikan secara empiris (bukan hanya literatur) klaim performa yang
disebut dalam laporan (Zulfa et al. 2020; Dipraja & Rahman 2025), yaitu
bahwa In-Memory Database (Redis) memiliki latency lebih rendah dan
throughput lebih tinggi dibanding basis data berbasis disk ketika
digunakan sebagai CACHE LAYER di atas query yang berat (query JOIN).

Skenario diambil langsung dari temuan Zulfa, Fadli & Wardhana (2020):
RDBMS berbasis disk mengalami bottleneck pada query JOIN yang kompleks.
Maka skenario uji berikut membandingkan:
  (A) SQLite  : setiap request menjalankan ulang query JOIN 3 tabel
                (products x categories x suppliers) dari disk - ini
                merepresentasikan pola akses "cache miss" / tanpa cache.
  (B) Redis   : hasil JOIN yang sama sudah di-precompute & disimpan
                sebagai cache (JSON), lalu setiap request tinggal GET -
                ini merepresentasikan pola "cache hit" (skenario Redis
                sebagai caching layer, bukan pengganti basis data utama).

Metrik yang diukur (sesuai materi Pertemuan 15 - Evaluasi Kinerja
Sistem Basis Data):
- Latency (ms)      : waktu rata-rata per operasi
- Throughput (ops/s): jumlah operasi yang selesai per detik

Redis diakses melalui unix socket (bukan TCP) untuk mengeliminasi
overhead jaringan yang tidak relevan pada perbandingan localhost,
sehingga hasil murni mencerminkan perbedaan mekanisme akses data
(disk I/O + query planner vs in-memory key lookup).
"""

import sqlite3
import time
import random
import statistics
import json
import os

import redis

# ---------------------------------------------------------------------------
# Konfigurasi pengujian
# ---------------------------------------------------------------------------
N_PRODUCTS = 20000      # jumlah baris produk di tabel disk-based (skala besar)
N_QUERIES = 3000        # jumlah query lookup yang diuji per run
RUNS = 5                # jumlah pengulangan pengujian (untuk rata-rata & stdev)
SQLITE_DB_PATH = "disk_based.db"
REDIS_SOCKET = "/tmp/redis_benchmark.sock"

RESULTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")
os.makedirs(RESULTS_DIR, exist_ok=True)
RESULTS_PATH = os.path.join(RESULTS_DIR, "benchmark_results.json")


def setup_sqlite(path, n_products):
    if os.path.exists(path):
        os.remove(path)
    conn = sqlite3.connect(path)
    cur = conn.cursor()
    cur.execute("CREATE TABLE suppliers (id INTEGER PRIMARY KEY, name TEXT)")
    cur.execute("CREATE TABLE categories (id INTEGER PRIMARY KEY, name TEXT)")
    cur.execute("""
        CREATE TABLE products (
            id INTEGER PRIMARY KEY,
            name TEXT,
            price REAL,
            category_id INTEGER,
            supplier_id INTEGER
        )
    """)
    cur.executemany("INSERT INTO suppliers VALUES (?, ?)",
                     [(i, f"Supplier-{i}") for i in range(200)])
    cur.executemany("INSERT INTO categories VALUES (?, ?)",
                     [(i, f"Category-{i}") for i in range(50)])
    cur.executemany(
        "INSERT INTO products VALUES (?, ?, ?, ?, ?)",
        [(i, f"Product-{i}", round(random.uniform(1000, 500000), 2),
          i % 50, i % 200) for i in range(n_products)]
    )
    conn.commit()
    return conn


def setup_redis():
    r = redis.Redis(unix_socket_path=REDIS_SOCKET, db=0)
    r.flushdb()
    return r


JOIN_QUERY = """
    SELECT p.id, p.name, p.price, c.name AS category, s.name AS supplier
    FROM products p
    JOIN categories c ON p.category_id = c.id
    JOIN suppliers s ON p.supplier_id = s.id
    WHERE p.id = ?
"""


def populate_redis_cache(r, conn, n_products):
    """Precompute hasil JOIN untuk setiap produk dan simpan sebagai cache di Redis."""
    cur = conn.cursor()
    start = time.perf_counter()
    pipe = r.pipeline(transaction=False)
    for i in range(n_products):
        cur.execute(JOIN_QUERY, (i,))
        row = cur.fetchone()
        payload = json.dumps({
            "id": row[0], "name": row[1], "price": row[2],
            "category": row[3], "supplier": row[4],
        })
        pipe.set(f"product:{i}", payload)
    pipe.execute()
    elapsed = time.perf_counter() - start
    return elapsed


def bench_sqlite_join_read(conn, product_ids):
    """Simulasi cache-miss: setiap request query ulang JOIN 3 tabel dari disk."""
    cur = conn.cursor()
    start = time.perf_counter()
    for pid in product_ids:
        cur.execute(JOIN_QUERY, (pid,))
        cur.fetchone()
    elapsed = time.perf_counter() - start
    return elapsed, len(product_ids)


def bench_redis_cache_read(r, product_ids):
    """Simulasi cache-hit: request cukup GET dari Redis, tanpa query ulang ke disk."""
    start = time.perf_counter()
    for pid in product_ids:
        r.get(f"product:{pid}")
    elapsed = time.perf_counter() - start
    return elapsed, len(product_ids)


# --- Skenario 2: Query analitik berat (agregasi tanpa index) ---------------
# Merepresentasikan laporan dashboard/analitik yang sering diminta berulang
# (mis. "rata-rata harga & jumlah produk per kategori di atas harga X"),
# skenario di mana biaya komputasi disk-based DB benar-benar signifikan.

AGG_QUERY = """
    SELECT category_id, COUNT(*), AVG(price)
    FROM products
    WHERE price > ?
    GROUP BY category_id
"""


def compute_aggregate(conn, threshold):
    cur = conn.cursor()
    cur.execute(AGG_QUERY, (threshold,))
    return cur.fetchall()


def bench_sqlite_agg_read(conn, thresholds):
    """Setiap request menjalankan ulang full scan + GROUP BY dari disk."""
    start = time.perf_counter()
    for t in thresholds:
        compute_aggregate(conn, t)
    elapsed = time.perf_counter() - start
    return elapsed, len(thresholds)


def bench_redis_agg_read(r, thresholds):
    """Setiap request tinggal GET hasil agregasi yang sudah di-cache."""
    start = time.perf_counter()
    for t in thresholds:
        r.get(f"agg:{t}")
    elapsed = time.perf_counter() - start
    return elapsed, len(thresholds)


def populate_redis_agg_cache(r, conn, thresholds):
    pipe = r.pipeline(transaction=False)
    for t in thresholds:
        result = compute_aggregate(conn, t)
        pipe.set(f"agg:{t}", json.dumps(result))
    pipe.execute()


def to_metrics(elapsed, n):
    latency_ms = (elapsed / n) * 1000
    throughput = n / elapsed
    return {"total_time_s": elapsed, "latency_ms_avg": latency_ms, "throughput_ops_s": throughput}


def run_benchmark():
    print(f"Setup data: {N_PRODUCTS} baris produk (JOIN products x categories x suppliers)")
    print(f"Menjalankan benchmark: {RUNS} run x {N_QUERIES} query lookup per run\n")

    sqlite_runs, redis_runs = [], []
    sqlite_agg_runs, redis_agg_runs = [], []
    cache_populate_times = []
    N_DISTINCT_THRESHOLDS = 20  # merepresentasikan variasi filter dashboard yang sering diulang

    for run in range(1, RUNS + 1):
        conn = setup_sqlite(SQLITE_DB_PATH, N_PRODUCTS)
        r = setup_redis()

        # Precompute cache Redis dari hasil JOIN SQLite (dilakukan sekali di awal,
        # merepresentasikan proses "cache warming")
        populate_time = populate_redis_cache(r, conn, N_PRODUCTS)
        cache_populate_times.append(populate_time)

        product_ids = [random.randint(0, N_PRODUCTS - 1) for _ in range(N_QUERIES)]

        # --- Skenario 1: Point lookup JOIN 3 tabel ---
        elapsed_sqlite, n = bench_sqlite_join_read(conn, product_ids)
        sqlite_runs.append(to_metrics(elapsed_sqlite, n))
        elapsed_redis, n = bench_redis_cache_read(r, product_ids)
        redis_runs.append(to_metrics(elapsed_redis, n))

        # --- Skenario 2: Query agregasi/analitik berat ---
        distinct_thresholds = [round(random.uniform(1000, 400000), 2) for _ in range(N_DISTINCT_THRESHOLDS)]
        populate_redis_agg_cache(r, conn, distinct_thresholds)
        thresholds_workload = [random.choice(distinct_thresholds) for _ in range(N_QUERIES)]

        elapsed_sqlite_agg, n = bench_sqlite_agg_read(conn, thresholds_workload)
        sqlite_agg_runs.append(to_metrics(elapsed_sqlite_agg, n))
        elapsed_redis_agg, n = bench_redis_agg_read(r, thresholds_workload)
        redis_agg_runs.append(to_metrics(elapsed_redis_agg, n))

        conn.close()
        print(f"Run {run}/{RUNS} selesai.")

    os.remove(SQLITE_DB_PATH)

    def summarize(runs):
        latencies = [x["latency_ms_avg"] for x in runs]
        throughputs = [x["throughput_ops_s"] for x in runs]
        return {
            "latency_ms_avg": round(statistics.mean(latencies), 4),
            "latency_ms_stdev": round(statistics.stdev(latencies), 4) if len(latencies) > 1 else 0,
            "throughput_ops_s_avg": round(statistics.mean(throughputs), 1),
        }

    def pct_change(before, after_label_dict, key):
        pass

    def compute_comparison(disk_summary, mem_summary):
        latency_reduction = (
            (disk_summary["latency_ms_avg"] - mem_summary["latency_ms_avg"])
            / disk_summary["latency_ms_avg"] * 100
        )
        throughput_increase = (
            (mem_summary["throughput_ops_s_avg"] - disk_summary["throughput_ops_s_avg"])
            / disk_summary["throughput_ops_s_avg"] * 100
        )
        return {
            "latency_reduction_percent": round(latency_reduction, 2),
            "throughput_increase_percent": round(throughput_increase, 2),
        }

    summary = {
        "scenario_1_point_lookup": {
            "description": "Point lookup JOIN 3 tabel (products x categories x suppliers) per produk. "
                            "SQLite = query JOIN dieksekusi ulang tiap request (cache-miss). "
                            "Redis = hasil JOIN sudah di-cache, tinggal GET (cache-hit).",
            "sqlite_disk_based": summarize(sqlite_runs),
            "redis_in_memory": summarize(redis_runs),
        },
        "scenario_2_heavy_aggregate": {
            "description": "Query analitik: COUNT + AVG + GROUP BY category dengan filter harga, "
                            "full table scan tanpa index (mensimulasikan query dashboard yang berat). "
                            "SQLite = agregasi dihitung ulang tiap request. "
                            "Redis = hasil agregasi sudah di-cache, tinggal GET.",
            "sqlite_disk_based": summarize(sqlite_agg_runs),
            "redis_in_memory": summarize(redis_agg_runs),
        },
        "config": {"n_products": N_PRODUCTS, "n_queries_per_run": N_QUERIES, "runs": RUNS},
        "cache_populate_time_s_avg": round(statistics.mean(cache_populate_times), 4),
    }

    summary["scenario_1_point_lookup"]["comparison"] = compute_comparison(
        summary["scenario_1_point_lookup"]["sqlite_disk_based"],
        summary["scenario_1_point_lookup"]["redis_in_memory"],
    )
    summary["scenario_2_heavy_aggregate"]["comparison"] = compute_comparison(
        summary["scenario_2_heavy_aggregate"]["sqlite_disk_based"],
        summary["scenario_2_heavy_aggregate"]["redis_in_memory"],
    )

    with open(RESULTS_PATH, "w") as f:
        json.dump(summary, f, indent=2)

    def print_scenario(title, data):
        print("\n" + "=" * 78)
        print(title)
        print("=" * 78)
        print(f"{'Metrik':<30}{'SQLite (Disk)':<24}{'Redis (In-Memory)':<24}")
        print("-" * 78)
        print(f"{'Latency rata-rata (ms)':<30}{data['sqlite_disk_based']['latency_ms_avg']:<24}{data['redis_in_memory']['latency_ms_avg']:<24}")
        print(f"{'Throughput (ops/s)':<30}{data['sqlite_disk_based']['throughput_ops_s_avg']:<24}{data['redis_in_memory']['throughput_ops_s_avg']:<24}")
        print("-" * 78)
        print(f"Perubahan latency (Redis vs SQLite)   : {data['comparison']['latency_reduction_percent']:+.2f}% "
              f"({'lebih cepat' if data['comparison']['latency_reduction_percent'] > 0 else 'lebih lambat'})")
        print(f"Perubahan throughput (Redis vs SQLite): {data['comparison']['throughput_increase_percent']:+.2f}% "
              f"({'lebih tinggi' if data['comparison']['throughput_increase_percent'] > 0 else 'lebih rendah'})")

    print(f"\nKonfigurasi: {N_PRODUCTS} baris produk, {N_QUERIES} query/run, {RUNS} run")
    print_scenario("SKENARIO 1: Point Lookup (JOIN sederhana 3 tabel)", summary["scenario_1_point_lookup"])
    print_scenario("SKENARIO 2: Query Analitik Berat (agregasi + GROUP BY, full scan)", summary["scenario_2_heavy_aggregate"])
    print(f"\nWaktu cache warming (populate ke Redis): {summary['cache_populate_time_s_avg']} detik")
    print(f"\nHasil lengkap disimpan di: {RESULTS_PATH}")


if __name__ == "__main__":
    run_benchmark()
